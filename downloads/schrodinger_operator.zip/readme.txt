heat_kernel.mpg: heat kernel evolution on a 100 nodes line graph
line.mpg: Schrödinger operator evolution on a 100 nodes line graph
circle.mpg: Schrödinger operator evolution on a 100 nodes circle graph
grid.mpg: Schrödinger operator evolution on a 100 nodes grid graph (4-connectivity)
er.mpg: Schrödinger operator evolution on a 100 nodes random graph
ba.mpg: Schrödinger operator evolution on a 100 nodes scale free graph
