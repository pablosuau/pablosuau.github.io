function A = erdos_renyi_graph(N,p)
    A = zeros(N,N);
    for i=1:N
        for j=i+1:N
            if (rand < p)
                A(i,j) = 1;
                A(j,i) = 1;
            end;
        end;
    end;