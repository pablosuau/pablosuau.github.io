function A = random_graph(N, d)
    A = zeros(N,N);
    
    totalEdges = (N*(N-1))/2;
    edges = zeros(2,totalEdges);
    
    % Generating all the edges
    pos = 1;
    for i=1:N
        for j=i+1:N
             edges(1,pos) = i;
             edges(2,pos) = j;
             pos = pos + 1;
        end;
    end;
    
    % Randomly shuffling the edges
    nedges = totalEdges;
    shuffle = randperm(nedges);
    
    % Computing the adjacency matrix
    for p=1:nedges*d
        i = edges(1,shuffle(p));
        j = edges(2,shuffle(p));
        A(i,j) = 1;
        A(j,i) = 1;
    end;
    
    
    