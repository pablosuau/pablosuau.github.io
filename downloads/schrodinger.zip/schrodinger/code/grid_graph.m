function A = grid_graph(n, eight)
    nodes = n*n;
    A = zeros(nodes);
    for i=1:nodes
        if (mod(i,n)~=1) A(i,i-1) = 1; end;
        if (mod(i,n)~=0) A(i,i+1) = 1; end;
        if (i>n) A(i,i-n) = 1; end;
        if (i<nodes-n+1) A(i,i+n) = 1; end;
	if (eight == 1) % 8 connectivity
		if (i<nodes - n && mod(i,n)~=0) A(i,i+n+1) = 1; end;
		if (i<=nodes-n+1 && mod(i-1,n)~=0) A(i,i+n-1) = 1; end;
		if (i>=n && mod(i,n)~=0) A(i,i-n+1) = 1; end;
		if (i>n+1 && mod(i-1,n)~=0) A(i,i-n-1)=1;end;
	end
    end;
