function L = laplacian_matrix(A)
    D = degree_matrix(A);
    L = D + A;