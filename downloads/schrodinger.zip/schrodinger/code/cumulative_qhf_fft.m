function cqhf = cumulative_qhf_fft(type,A,T)
    [f,Y] = quantum_heat_flow_frequency_domain(type,A,T,0);
    n = size(Y,2);
    
    % Normalizing the frequency domain trace
    total = sum(sum(Y));
    Y = Y./total;
    
    % Building the cumulative distribution
    cqhf = zeros(1,n);
    cqhf(1) = Y(1);
    for i=2:n
        cqhf(i) = cqhf(i-1) + Y(i);
    end
    