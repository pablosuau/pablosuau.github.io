function D = degree_matrix(A)
    n = size(A,1);
    D = zeros(n,n);
    for i=1:n
        D(i,i) = sum(A(i,:));
    end;
    