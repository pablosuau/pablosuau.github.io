function L = normalized_laplacian_matrix(A)
    D = degree_matrix(A);
    
    n = size(A,1);
    L = zeros(n,n);
    
    for i=1:n
        for j=1:n
            if (i==j)
                if (D(i,i) ~= 0)
                    L(i,j) = 1;
                end;
            else
                if (A(i,j) == 1)
                    L(i,j) = -1/sqrt(D(i,i)*D(j,j));
                end;
            end;
        end;
    end;