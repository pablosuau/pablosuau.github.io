function A = barabasi_albert_graph(N,m0,m)
    A = zeros(N,N);
    if (m0 >= 2 && m>=1 && m<=m0)
        % Initial graph
        for i=1:m0-1
            A(i,i+1) = 1;
            A(i+1,i) = 1;
        end;
        % Adding nodes
        for i=m0+1:N
            % Computing probability to link to each node
            D = degree_matrix(A);
            P = diag(D);
            total_degree = sum(sum(P));
            P = P/total_degree;
            % Selecting nodes
            cumP = P;
            for j=2:i
                cumP(j) = cumP(j) + cumP(j-1);
            end
            selected = [];
            num_selected = 0;
            while (num_selected < m)
                p = rand;
                v = 1;
                while (p>cumP(v))
                    v = v + 1;
                end;
                if (~any(selected==v))
                    selected = [selected v];
                    num_selected = num_selected + 1;
                end
            end;
            % Modifying adjacency matrix
            for j=1:m
                A(i,selected(j)) = 1;
                A(selected(j),i) = 1;
            end;
        end
    end;
    
    % DEBUG: degree frequency
%     D = degree_matrix(A);
%     D = diag(D);
%     hist(D,max(max(D)));