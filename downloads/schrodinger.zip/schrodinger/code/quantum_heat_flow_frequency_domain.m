function [f, Y] = quantum_heat_flow_frequency_domain(type, A, T, normalize)
    NFFT = 2^nextpow2(T);
    f = T/2*linspace(0,1,NFFT/2+1);
    [Ts, tracef] = quantum_heat_flow(type, A, T);
    Y = fft(tracef,NFFT)/T;
    Y = abs(Y(1:NFFT/2+1));
    
    if (normalize == 1)
        maxY = max(max(Y));
        Y = Y./maxY;
    end
    