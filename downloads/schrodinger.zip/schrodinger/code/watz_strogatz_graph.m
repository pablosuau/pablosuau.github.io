function A = watz_strogatz_graph(N,K,b)
    A = zeros(N,N);
    % Building the regular letice
    for i=1:N
        for j=i+1:N
            dif = abs(i-j);
            if (dif>0 && dif<=K/2)
                A(i,j) = 1;
                A(j,i) = 1;
            end;
        end
    end
    % Randomly rewiring
    for i=1:N
        edges = find(A(i,:));
        n_edges = size(edges,2);
        for j=1:n_edges
            if rand<=b
                v = randi(N);
                while (any(v==find(A(i,:))))
                    v = randi(N);
                end;
                A(i,edges(j)) = 0;
                A(edges(j),i) = 0;
                A(i,v) = 1;
                A(v,i) = 1;
            end;
        end;
    end