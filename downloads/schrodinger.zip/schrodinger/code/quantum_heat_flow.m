function [Ts, tracef] = quantum_heat_flow(type, A, T)
   % Number of vertices
    n = size(A,1);
    
    switch (type)
        case 0
            L = A;
        case 1
            % Laplacian matrix
            L = laplacian_matrix(A);
        case 2
            % Normalized laplacian
            L = normalized_laplacian_matrix(A);
        case 3
            % Signless laplacian
            L = signless_laplacian_matrix(A);
    end;
    
    % Trace computation
    Ts = 0:0.1:T;
    tracef = zeros(1,size(Ts,2));
    pos = 1;
    for t = Ts
        % Quantum mechanics kernel
        [C,S,cost,s] = cosmsinm(t*L);
        Psi = C - i*S;
        
        % Instantaneous flow computation
        % Using the conjugate transpose rather than the transpose (because
        % Psi contains complex numbers) in order to compute the Frobenius
        % inner product
        X = trace(A*Psi');
        %tracef(pos) = imag(X)^2 + real(X)^2;
        tracef(pos) = X*conj(X); % Modulus computed using the complex conjugate
        
        pos = pos + 1;
    end;
    