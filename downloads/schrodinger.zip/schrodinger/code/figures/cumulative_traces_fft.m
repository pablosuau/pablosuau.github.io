function [cqhfA, cqhfB, cqhfC, cqhfD, cqhfE] = cumulative_traces_fft
    T = 1024;

    cd ..
    [A,B,C,D,E] = sample_graphs;
    cqhfA = cumulative_qhf_fft(3,A,T);
    cqhfB = cumulative_qhf_fft(3,B,T);
    cqhfC = cumulative_qhf_fft(3,C,T);
    cqhfD = cumulative_qhf_fft(3,D,T);
    cqhfE = cumulative_qhf_fft(3,E,T);
    
    figure
    hold on
    plot(cqhfA,'Color',[0,0,0],'LineWidth',2);
    plot(cqhfB,'Color',[0.5,0.5,0.5],'LineWidth',2);
    plot(cqhfC,'Color',[0.8,0.8,0.8],'LineWidth',2);
    plot(cqhfD,'--','Color',[0,0,0],'LineWidth',2);
    plot(cqhfE,'--','Color',[0.8,0.8,0.8],'LineWidth',2);
    set(gca,'FontSize',20);
    xlabel('frequency (Hz)');
    ylabel('accumulated amplitude');
    legend('Gauss10','Grid8N10','Grid4N10','Line10','Circle10','Location','SouthEast');
    ylim([0,1.01]);
    xlim([0,size(cqhfA,2)]);
    cd figures
    
    saveas(gcf,'output/SL_cumulative_traces_fft.eps','epsc');