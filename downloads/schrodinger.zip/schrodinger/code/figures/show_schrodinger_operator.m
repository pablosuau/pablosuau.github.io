% value of type
% 0 - adjacency
% 1 - laplacian
% 2 - normalized laplacian
% 3 - signless laplacian
function show_schrodinger_operator(type, A,T,video_filename)
    %fps = 24;

	close all hidden;
	%fig1 = figure(1);
    %set(gcf,'XVisual','0x21');
    %winsize = get(fig1,'Position');
    
    %winsize(1:2) = [0 0];
    %numframes = fps*(T+1);
    %M = moviein(numframes, fig1, winsize);
    %set(fig1,'NextPlot','replacechildren');
    
	
	cd ..
    switch (type)
        case 0
            L = A;
        case 1
            L = laplacian_matrix(A);
        case 2
            L = normalized_laplacian_matrix(A);
        case 3
            L = signless_laplacian_matrix(A);
        otherwise
            fprintf(1,'type error');
            return;
    end;
	cd figures
    

	n = size(L,1);
                                                                                               
    f = 1;
	%for t=0:1/fps:T
    for t=[1 25 50]
        %fprintf(1,'t=%f\n',t);
		cd ..
		[C,S,cost,s] = cosmsinm(t*L);
        Psi = C - i*S;

		amplitudes = Psi;
		for u=1:n
			for v=1:n
				amplitudes(u,v) = amplitudes(u,v)*conj(amplitudes(u,v));
			end
		end
		surf(amplitudes, 'EdgeColor', 'none','FaceColor','interp');
		colormap('Gray');
		zlim([0,1]);
		%pause(0.05)
        %if (t==1 || t == 25 || t == 50)
            output_filename = sprintf('figures/output/%s_%d.eps',video_filename,t);
            saveas(gcf,output_filename,'epsc');
        %end;
        %M(:,f) = getframe(fig1,winsize);
        %f = f + 1;
		clf
		
		cd figures
    end
    %close all hidden
    
    %movie(fig1,M,1,24,winsize);
    
    %writerObj = VideoWriter(video_filename);
    %open(writerObj);
    %writeVideo(writerObj,M);
    %close(writerObj);
    
    %cd mpgwrite
    %filename = sprintf('../%s.mpg',video_filename);
    %mpgwrite(M,jet,filename);
    %cd ..
    
	
