function show_synthetic_experiment_results(type)
    filename = sprintf('../experiments/results/synthetic_%d.mat',type);

	load(filename);
	
    random_graph_fft = random_graphs_results;
	scale_free_graph_fft = scale_free_graphs_results;
	small_world_graph_fft = small_world_graphs_results;
    
	figure
	hold on
	for i=1:32
 		plot(random_graph_fft(i,:),'Color',[0,0,0],'LineWidth',2);
 		plot(scale_free_graph_fft(i,:),'Color',[0.5,0.5,0.5],'LineWidth',2);
 		plot(small_world_graph_fft(i,:),'Color',[0.8,0.8,0.8],'LineWidth',2);
    end
	xlim([0,513]);
	legend('Random','Scale free', 'Small world', 'Location', 'SouthEast');
    set(gca,'FontSize',20);
    xlabel('frequency (Hz)');
    ylabel('accumulated amplitude');
    
    filename = sprintf('output/synthetic_%d.eps',type);
	saveas(gcf,filename,'epsc');

% 	figure
% 	hold on
% 	hold on
% 	for i=1:32
% 		plot(random_graph_fft_logy(i,:),'r','LineWidth',2);
% 		plot(scale_free_graph_fft_logy(i,:),'g','LineWidth',2);
% 		plot(small_world_graph_fft_logy(i,:),'b','LineWidth',2);
% 	end
% 	title('FFT LOGY');
% 	xlim([0,513]);
% 	legend('Random','Scale free', 'Small world', 'Location', 'SouthEast');
% 	saveas(gcf,'output/synthetic2_fft_logy.eps','epsc');
