function create_video(graph_type, matrix_type)
    cd ..
    
    switch(graph_type)
        case 0
            graph = 'line';
            A = line_graph(100); 
        case 1
            graph = 'circle';
            A = circle_graph(100);
        case 2
            graph = 'grid4N';
            A = grid_graph(10,0);
        case 3
            graph = 'grid8N';
            A = grid_graph(10,1);
        case 4
            graph = 'er';
            load('ER_A');
        case 5
            graph = 'ba';
            load('BA_A');
    end
    
    switch(matrix_type)
        case 0
            type = 'A';
        case 1
            type = 'L';
        case 2
            type = 'NL';
        case 3
            type = 'SL';
    end;
    
    filename  = sprintf('%s_%s',type, graph)
    cd figures
    
    show_schrodinger_operator(matrix_type, A,100,filename);
    
    