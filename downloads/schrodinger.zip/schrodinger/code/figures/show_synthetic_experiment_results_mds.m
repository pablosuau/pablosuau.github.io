function show_synthetic_experiment_results_mds(type)
    filename = sprintf('../experiments/results/synthetic_%d.mat',type);

    load(filename);
    
    all_traces = [random_graphs_results; scale_free_graphs_results; small_world_graphs_results];
    
    % Computing distances
    distances = zeros(96,96);
    for i=1:96
        for j=i+1:96
            for k=1:512
                distances(i,j) = distances(i,j) + (all_traces(i,k) - all_traces(j,k))^2;
            end;
            distances(i,j) = sqrt(distances(i,j));
            distances(j,i) = distances(i,j);
        end;
    end,
    
    % MDS computation
    Y = mdscale(distances,3);
    
    figure
    hold on
    plot(Y(1:32,1),Y(1:32,2),'ko');
    plot(Y(33:64,1),Y(33:64,2),'k*');
    plot(Y(65:96,1),Y(65:96,2),'k^');
    legend('Random','Scale free', 'Small world', 'Location', 'NorthEast');
    grid on
    set(gca,'FontSize',18);
    xlabel('dimension 1');
    ylabel('dimension 2');
    
    filename = sprintf('output/synthetic_mds_%d.eps',type);
    saveas(gcf,filename,'epsc');