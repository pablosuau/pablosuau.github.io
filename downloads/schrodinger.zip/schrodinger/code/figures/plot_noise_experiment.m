function plot_noise_experiment(type)
    file_name = sprintf('../experiments/results/noise_%d.mat',type);
    load(file_name);
    
    figure
    hold on
    plot(noise_results(1,:),'k:','LineWidth',2);
    plot(noise_results(2,:),'k--','LineWidth',2);
    plot(noise_results(3,:),'k-.','LineWidth',2);
    plot(noise_results(4,:),'k','LineWidth',2);
    
    set(gca,'FontSize',20);
    xlim([1,35]);
    xlabel('Removed edges');
    ylabel('Euclidean distance');
    grid on;
    legend('T=64','T=128','T=256','T=512','Location','NorthWest');
    
    file_name = sprintf('output/noise_experiment_%d.eps',type);
    saveas(gcf,file_name,'epsc');