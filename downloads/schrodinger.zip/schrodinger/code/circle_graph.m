function A = circle_graph(N)
    A = zeros(N,N);
    for i=2:N-1
        A(i,i-1) = 1;
        A(i,i+1) = 1;
    end;
    A(1,N) = 1;
    A(N,1) = 1;
    A(1,2) = 1;
    A(N,N-1) = 1;