function noise_experiment(type)
    cd ..
    N = 400;
    
    A = random_graph(N,0.8);
    noise_results = zeros(4,35);
    Ts = [64, 128, 256, 512];
    
    for i=1:4
        T = Ts(i);
        fprintf(1,'T=%d\n',T);
        [f,Ya] = quantum_heat_flow_frequency_domain(type,A,T,1);
        len = size(Ya,2);
        Ap = A;
        
        for j=1:35
            % Removing one edge
            removed = 0;
            while removed == 0
                m = randi(N);
                n = randi(N);
                if (Ap(m,n) == 1)
                    Ap(m,n) = 0;
                    Ap(n,m) = 0;
                    removed = 1;
                end;
            end;
            
            % Estimating noise
            fprintf(1,'T=%d   %d/35\n', T, j);
            [f,Y] = quantum_heat_flow_frequency_domain(type,Ap,T,1);
            for k=1:len
                noise_results(i,j) = noise_results(i,j) + (Ya(k) - Y(k))^2;
            end;
        end;
    end;
    
    cd experiments
    
    filename = sprintf('results/noise_%d.mat',type);
    
    save(filename,'noise_results');