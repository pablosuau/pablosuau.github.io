function synthetic_experiment(type)
    load('datasets/synthetic.mat');
    
    random_graphs_results = zeros(32,513);
    scale_free_graphs_results = zeros(32,513);
    small_world_graphs_results = zeros(32,513);
    
    cd ..
    
    for k=1:32
        	fprintf(1,'FFT %d/32\n',k);
            random_graphs_results(k,:) = cumulative_qhf_fft(type,random_graphs{3,2,k},1024);
            scale_free_graphs_results(k,:) = cumulative_qhf_fft(type,scale_free_graphs{3,2,k},1024);
            small_world_graphs_results(k,:) = cumulative_qhf_fft(type,small_world_graphs{3,2,k},1024);
     end;

    
    cd experiments

    filename = sprintf('results/synthetic_%d.mat', type);
    save(filename,'random_graphs_results','scale_free_graphs_results','small_world_graphs_results');

