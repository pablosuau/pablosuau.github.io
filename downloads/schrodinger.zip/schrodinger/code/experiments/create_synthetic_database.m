function create_synthetic_database
    N = [50,70,90];
    P = [0.1,0.2,0.3];
    M0 = 5;
    M = [1,2,3];
    K = 10;
    NG = 632; % Number of graphs
    
    random_graphs = cell(3,3,NG);
    scale_free_graphs = cell(3,3,NG);
    small_world_graphs = cell(3,3,NG);
    
    cd ..
    
    for i=1:3
        for j=1:3
            for k=1:32
                random_graphs{i,j,k} = erdos_renyi_graph(N(i),P(j));
                scale_free_graphs{i,j,k} = barabasi_albert_graph(N(i),M0,M(j));
                small_world_graphs{i,j,k} = watz_strogatz_graph(N(i),K,P(j));
            end;
        end;
    end;
    
    %DEBUG
%     for i=1:3
%         plot_graph(random_graphs{1,i,1});
%         pause
%         clf
%         plot_graph(scale_free_graphs{1,i,1});
%         pause
%         clf
%         plot_graph(small_world_graphs{1,i,1});
%         pause
%         clf
%     end;
%     close all hidden;
    %END DEBUG
    
    cd experiments
    
    save('datasets/synthetic.mat','random_graphs','scale_free_graphs','small_world_graphs');
   
