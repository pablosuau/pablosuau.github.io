function A = line_graph(N)
    A = circle_graph(N);
    A(1,N) = 0;
    A(N,1) = 0;