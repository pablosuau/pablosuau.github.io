heat_kernel.mpg: heat kernel evolution on a 100 nodes line graph

ba.mp4, er.mp4, line.mp4, circle.mp4, grid4N.mp4, grid8N.mp4: schrödinger operator evolution for several types of 100 nodes graph 
(small world, random, line, circle, 4-neighbour grid, 8-neighbour grid) using four different types of matrix as hamiltonians 
(from left to right and from top to bottom: adjacency, laplacian, normalized laplacian, signless laplacian).


